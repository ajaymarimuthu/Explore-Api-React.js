import React from 'react'

function Home() {
  return (
    <div>Home component</div>
  )
}

export default Home