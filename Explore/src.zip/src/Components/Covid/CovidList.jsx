 
 

import React from 'react'
import CovidNavbar from './CovidNavbar'
 

function CovidList() {
  return (
    <div>

        <CovidNavbar/>
      


    </div>
  )
}

export default CovidList